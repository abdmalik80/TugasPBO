// Interface
interface Sewa {
    void dipinjam();
    void dikembalikan();
}

// Abstract Class
abstract class Kendaraan {
    protected String nomorPolisi;
    protected String merk;
    protected String warna;

    public Kendaraan(String nomorPolisi, String merk, String warna) {
        this.nomorPolisi = nomorPolisi;
        this.merk = merk;
        this.warna = warna;
    }

    public abstract void tampilkanInfo();
}

// Subclass Mobil
class Mobil extends Kendaraan implements Sewa {
    public Mobil(String nomorPolisi, String merk, String warna) {
        super(nomorPolisi, merk, warna);
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Mobil: " + merk + ", Warna: " + warna + ", NoPol: " + nomorPolisi);
    }

    @Override
    public void dipinjam() {
        System.out.println("Mobil sedang dipinjam.");
    }

    @Override
    public void dikembalikan() {
        System.out.println("Mobil telah dikembalikan.");
    }
}

// Class Supir
class Supir {
    private final String nip;
    private final String nama;

    public Supir(String nip, String nama) {
        this.nip = nip;
        this.nama = nama;
    }

    public void tampilkanInfoSupir() {
        System.out.println("Supir: " + nama + " (NIP: " + nip + ")");
    }
}

// Class Rental
class Rental {
    private final String tanggalPinjam;
    private final String tanggalKembali;
    private final Mobil mobil;
    private final Supir supir;

    public Rental(String tanggalPinjam, String tanggalKembali, Mobil mobil, Supir supir) {
        this.tanggalPinjam = tanggalPinjam;
        this.tanggalKembali = tanggalKembali;
        this.mobil = mobil;
        this.supir = supir;
    }

    public void cetakStruk() {
        System.out.println("\n== STRUK RENTAL ==");
        mobil.tampilkanInfo();
        supir.tampilkanInfoSupir();
        System.out.println("Tanggal Pinjam   : " + tanggalPinjam);
        System.out.println("Tanggal Kembali  : " + tanggalKembali);
    }
}

// Main Class
public class Main {
    public static void main(String[] args) {
        Mobil m = new Mobil("D 1234 AB", "Toyota Avanza", "Hitam");
        Supir s = new Supir("19810101", "Budi");
        Rental r = new Rental("2025-05-01", "2025-05-03", m, s);

        m.dipinjam();
        r.cetakStruk();
        m.dikembalikan();
    }
}
